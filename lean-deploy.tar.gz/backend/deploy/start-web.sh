#!/bin/sh
set -eu
# Refresh the mounted static volume on every release before accepting traffic.
python manage.py collectstatic --noinput
exec "$@"
