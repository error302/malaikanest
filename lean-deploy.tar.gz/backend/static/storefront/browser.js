(() => {
  const notice = document.getElementById("connection-notice");
  const updateNetwork = () => { if (notice) notice.hidden = navigator.onLine; };
  window.addEventListener("online", updateNetwork);
  window.addEventListener("offline", updateNetwork);
  updateNetwork();
  const viewport = window.visualViewport;
  const updateKeyboard = () => {
    const editable = document.activeElement?.matches("textarea, input:not([type=radio]):not([type=checkbox])");
    document.documentElement.classList.toggle("keyboard-open", !!editable && !!viewport && window.innerHeight - viewport.height > 150);
  };
  viewport?.addEventListener("resize", updateKeyboard);
  document.addEventListener("focusin", updateKeyboard);
  document.addEventListener("focusout", () => requestAnimationFrame(updateKeyboard));
  if ("serviceWorker" in navigator && window.isSecureContext) {
    window.addEventListener("load", () => { navigator.serviceWorker.register("/sw.js").catch(() => { /* Normal online navigation remains available. */ }); });
  }
})();
