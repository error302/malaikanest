import { useState } from "react";
import { api, ApiError } from "./api";

export function Login({ onDone }: { onDone: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      await api.login(username.trim(), password);
      onDone();
    } catch (err) {
      setError(
        err instanceof ApiError
          ? err.message
          : "Invalid credentials or account locked. Please try again."
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      className="login-wrap"
      style={{
        background: "linear-gradient(135deg, #FAF7F2 0%, #EADBCE 100%)",
      }}
    >
      <form
        className="login-card"
        onSubmit={submit}
        style={{
          borderRadius: "16px",
          boxShadow: "0 12px 40px rgba(44, 24, 16, 0.12)",
          border: "1px solid #EADBCE",
          padding: "44px 38px",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: "24px" }}>
          <div
            style={{
              width: "56px",
              height: "56px",
              borderRadius: "14px",
              background: "#2C1810",
              color: "#FAF7F2",
              margin: "0 auto 14px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 800,
              fontSize: "20px",
              letterSpacing: "0.5px",
              boxShadow: "0 4px 14px rgba(44, 24, 16, 0.2)",
            }}
          >
            MN
          </div>
          <h1
            style={{
              fontSize: "24px",
              color: "#2C1810",
              fontWeight: 800,
              margin: "0 0 6px",
            }}
          >
            Malaika Nest
          </h1>
          <p
            className="sub"
            style={{
              fontSize: "13px",
              color: "#7A685D",
              margin: 0,
              fontWeight: 500,
            }}
          >
            Store Operations &amp; Management Portal
          </p>
        </div>

        {error && (
          <div
            className="error"
            role="alert"
            style={{
              marginBottom: "18px",
              padding: "10px 14px",
              borderRadius: "8px",
              fontSize: "13px",
              fontWeight: 500,
            }}
          >
            {error}
          </div>
        )}

        <label className="field" style={{ marginBottom: "16px" }}>
          <span style={{ fontSize: "12px", fontWeight: 600, color: "#3D2B1F" }}>
            Staff Email Address
          </span>
          <input
            type="email"
            value={username}
            autoFocus
            autoComplete="username"
            placeholder="admin@malaikanest.com"
            onChange={(e) => setUsername(e.target.value)}
            disabled={busy}
            required
            style={{
              padding: "10px 12px",
              borderRadius: "8px",
              border: "1px solid #D5C7B8",
              fontSize: "14px",
            }}
          />
        </label>

        <label className="field" style={{ marginBottom: "22px" }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "4px",
            }}
          >
            <span style={{ fontSize: "12px", fontWeight: 600, color: "#3D2B1F" }}>
              Password
            </span>
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              style={{
                background: "none",
                border: "none",
                fontSize: "11px",
                color: "#8B6914",
                cursor: "pointer",
                fontWeight: 600,
                padding: 0,
              }}
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>
          <input
            type={showPassword ? "text" : "password"}
            value={password}
            autoComplete="current-password"
            placeholder="••••••••••••"
            onChange={(e) => setPassword(e.target.value)}
            disabled={busy}
            required
            style={{
              padding: "10px 12px",
              borderRadius: "8px",
              border: "1px solid #D5C7B8",
              fontSize: "14px",
            }}
          />
        </label>

        <button
          className="btn"
          disabled={busy}
          type="submit"
          style={{
            width: "100%",
            padding: "12px",
            borderRadius: "8px",
            background: "#2C1810",
            color: "#FAF7F2",
            fontWeight: 700,
            fontSize: "14px",
            cursor: busy ? "not-allowed" : "pointer",
            border: "none",
            boxShadow: "0 4px 12px rgba(44, 24, 16, 0.18)",
            transition: "all 0.15s ease",
          }}
        >
          {busy ? "Authenticating session…" : "Sign In to Store"}
        </button>

        <div
          style={{
            marginTop: "24px",
            paddingTop: "16px",
            borderTop: "1px solid #EADBCE",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            fontSize: "11px",
            color: "#8A796E",
          }}
        >
          <span>🔒 TLS 1.3 256-bit Encrypted</span>
          <span>•</span>
          <span>Brute-force Guarded</span>
        </div>
      </form>
    </div>
  );
}
