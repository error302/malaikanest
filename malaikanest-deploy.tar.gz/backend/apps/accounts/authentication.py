"""
JWT Authentication with Refresh Token Rotation
Provides secure token handling with automatic rotation
"""
import logging
from datetime import timedelta
from django.utils import timezone
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from rest_framework_simplejwt.settings import api_settings

logger = logging.getLogger('security')


class CookieJWTAuthentication(JWTAuthentication):
    """
    Custom authentication class that checks for the 'access_token' in
    HTTPOnly cookies instead of just the Authorization header.
    """
    def authenticate(self, request):
        # Default behavior: checks Authorization header first
        header = self.get_header(request)
        
        if header is None:
            # If no Authorization header, look for cookie
            raw_token = request.COOKIES.get('access_token')
            if not raw_token:
                return None
        else:
            raw_token = self.get_raw_token(header)
            if raw_token is None:
                return None

        # Important: if the cookie contains an expired/invalid token we should
        # treat it as "no credentials" instead of hard-failing the request.
        # Otherwise public endpoints and the refresh endpoint get stuck in 401 loops.
        try:
            validated_token = self.get_validated_token(raw_token)
            
            # P0 Security Check: Validate against Redis blacklist
            from django.core.cache import cache
            jti = validated_token.payload.get('jti')
            if jti and cache.get(f"blacklisted_jti_{jti}"):
                if header is not None:
                    raise InvalidToken("Token has been blacklisted")
                return None
                
        except (InvalidToken, TokenError):
            # If the client explicitly sent an Authorization header, keep strict behavior.
            if header is not None:
                raise
            return None

        return self.get_user(validated_token), validated_token


class JWTAuthenticationWithRotation(JWTAuthentication):
    """
    JWT Authentication with automatic refresh token rotation.
    Implements refresh token rotation to prevent token reuse attacks.
    """
    
    def authenticate(self, request):
        result = super().authenticate(request)
        
        if result is None:
            return None
            
        user, validated_token = result
        
        # Check if token is about to expire (within 5 minutes)
        if self._token_is_expiring_soon(validated_token):
            # Token is expiring soon, but we don't auto-refresh here
            # The frontend should use the refresh endpoint
            pass
        
        # Log successful authentication
        logger.info(f"User {user.email} authenticated successfully")
        
        return (user, validated_token)
    
    def _token_is_expiring_soon(self, token, threshold_minutes=5):
        """Check if token will expire within threshold minutes"""
        try:
            exp = token.payload.get('exp')
            if exp:
                from datetime import datetime
                expiry = datetime.fromtimestamp(exp, tz=timezone.utc)
                threshold = timedelta(minutes=threshold_minutes)
                return expiry - timezone.now() < threshold
        except Exception:
            logger.debug("Token expiry check failed")
        return False
    
    def get_user(self, validated_token):
        """
        Override to add additional security checks
        """
        user = super().get_user(validated_token)
        
        # Check if user is active
        if not user.is_active:
            raise InvalidToken("User account is disabled")
        
        return user


class TokenRotationMixin:
    """
    Mixin to handle refresh token rotation
    """
    
    @classmethod
    def get_token(cls, user):
        from rest_framework_simplejwt.tokens import RefreshToken
        
        # Invalidate any existing tokens for this user
        # This prevents token reuse after logout
        token = RefreshToken.for_user(user)
        
        # Add custom claims
        token['email'] = user.email
        token['role'] = user.role
        token['is_admin'] = user.is_staff

        # Set absolute expiry
        from datetime import timedelta
        from django.conf import settings

        # Add token version for invalidation. User.token_version is the source of
        # truth (the dead `user.profile.token_version` reference has been removed);
        # bumping it on password change/logout-everywhere revokes outstanding tokens.
        token['token_version'] = user.token_version
        
        return token
    
    def refresh(self, request):
        """
        Override to implement refresh token rotation
        """
        from rest_framework.response import Response
        from rest_framework import status
        
        try:
            refresh_token = request.data.get('refresh')
            
            if not refresh_token:
                return Response(
                    {'detail': 'Refresh token is required'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Validate the refresh token
            token = RefreshToken(refresh_token)
            
            # Check token version
            token_version = token.payload.get('token_version', 1)

            # Get user and check version
            user = self.user_from_token(token)
            # A bumped token_version means the user changed their password (or hit
            # logout-everywhere); treat the token as revoked.
            if user.token_version != token_version:
                # Token was invalidated
                return Response(
                    {'detail': 'Token has been revoked'},
                    status=status.HTTP_401_UNAUTHORIZED
                )
            
            # Generate new tokens (rotation)
            new_token = self.get_token(user)
            
            # Blacklist old refresh token
            token.blacklist()
            
            return Response({
                'access': str(new_token.access_token),
                'refresh': str(new_token),
            })
            
        except TokenError as e:
            return Response(
                {'detail': str(e)},
                status=status.HTTP_401_UNAUTHORIZED
            )


def invalidate_all_user_tokens(user):
    """
    Invalidate all tokens for a user by incrementing their token version.
    Call this when the user changes password or is disabled/logged out everywhere.
    Outstanding refresh tokens will fail the version check at refresh time.
    """
    from django.db import transaction

    with transaction.atomic():
        # Refresh to avoid lost updates and ensure we bump the latest value.
        user = type(user).objects.select_for_update().get(pk=user.pk)
        user.token_version += 1
        user.save(update_fields=["token_version", "updated_at"])
        logger.warning(f"All tokens invalidated for user {user.email}")
