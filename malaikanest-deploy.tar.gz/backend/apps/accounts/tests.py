from django.contrib.auth import get_user_model
from rest_framework import status
from rest_framework.test import APITestCase


User = get_user_model()


class AuthCookieLoginTests(APITestCase):
    def test_customer_login_sets_http_only_cookies_and_profile_works(self):
        password = "StrongPass123!"
        User.objects.create_user(
            email="customer@example.com",
            phone_number="+254700111222",
            password=password,
            role="CUSTOMER",
        )

        response = self.client.post(
            "/api/accounts/token/",
            {"email": "customer@example.com", "password": password},
            format="json",
            secure=True,
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertNotIn("refresh", response.data)
        self.assertIn("refresh_token", response.cookies)
        self.assertTrue(response.cookies["refresh_token"]["httponly"])
        self.assertIn("access", response.data)

        access = response.data["access"]
        profile = self.client.get(
            "/api/accounts/profile/",
            secure=True,
            HTTP_AUTHORIZATION=f"Bearer {access}",
        )
        self.assertEqual(profile.status_code, status.HTTP_200_OK)
        self.assertEqual(profile.data["email"], "customer@example.com")
        self.assertEqual(profile.data["role"], "CUSTOMER")

    def test_admin_login_sets_cookies_and_can_access_admin_reconcile_endpoint(self):
        password = "AdminStrongPass123!"
        admin = User.objects.create_superuser(
            email="admin@example.com",
            phone_number="+254700333444",
            password=password,
        )

        login = self.client.post(
            "/api/accounts/token/",
            {"email": admin.email, "password": password},
            format="json",
            secure=True,
        )
        self.assertEqual(login.status_code, status.HTTP_200_OK)
        self.assertIn("refresh_token", login.cookies)
        self.assertIn("access", login.data)

        profile = self.client.get(
            "/api/accounts/profile/",
            secure=True,
            HTTP_AUTHORIZATION=f"Bearer {login.data['access']}",
        )
        self.assertEqual(profile.status_code, status.HTTP_200_OK)
        self.assertEqual(profile.data["role"], "ADMIN")

        reconcile = self.client.get(
            "/api/payments/admin/reconcile/candidates/",
            secure=True,
            HTTP_AUTHORIZATION=f"Bearer {login.data['access']}",
        )
        self.assertEqual(reconcile.status_code, status.HTTP_200_OK)

    def test_admin_login_endpoint_allows_admin_and_sets_http_only_cookies(self):
        password = "AdminOnlyPass123!"
        admin = User.objects.create_superuser(
            email="owner@example.com",
            phone_number="+254700555666",
            password=password,
        )

        response = self.client.post(
            "/api/accounts/admin/login/",
            {"email": admin.email, "password": password},
            format="json",
            secure=True,
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("refresh_token", response.cookies)
        self.assertTrue(response.cookies["refresh_token"]["httponly"])
        self.assertIn("access", response.data)

        session = self.client.get(
            "/api/accounts/admin/session/",
            secure=True,
            HTTP_AUTHORIZATION=f"Bearer {response.data['access']}",
        )
        self.assertEqual(session.status_code, status.HTTP_200_OK)
        self.assertEqual(session.data["email"], admin.email)
        self.assertTrue(session.data["is_staff"])

    def test_admin_login_endpoint_rejects_non_admin_users(self):
        password = "CustomerPass123!"
        customer = User.objects.create_user(
            email="shopper@example.com",
            phone_number="+254700777888",
            password=password,
            role="CUSTOMER",
        )

        response = self.client.post(
            "/api/accounts/admin/login/",
            {"email": customer.email, "password": password},
            format="json",
            secure=True,
        )

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(response.data["detail"], "Admin access required")

    def test_inactive_user_login_returns_verify_message(self):
        password = "VerifyMe123!"
        User.objects.create_user(
            email="inactive@example.com",
            phone_number="+254701111222",
            password=password,
            role="CUSTOMER",
            is_active=False,
        )

        response = self.client.post(
            "/api/accounts/token/",
            {"email": "inactive@example.com", "password": password},
            format="json",
            secure=True,
        )

        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
        # Custom exception handler wraps errors in {status, error: {message, code, details}}
        error_msg = (
            response.data.get("detail", "")
            or response.data.get("message", "")
            or response.data.get("error", {}).get("message", "")
        )
        self.assertIn("verify your email", str(error_msg).lower())
