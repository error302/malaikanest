from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CartViewSet, OrderViewSet, GuestOrderTrackView, DeliveryZonesView
from .admin_views import (
    AdminAnalyticsView,
    AdminReportsView,
    OrdersCSVExportView,
    InvoiceListView,
    InvoiceDetailView,
    InvoiceDownloadView,
    InvoiceRegenerateView,
    InvoiceResendView,
    AdminAbandonedCartsView,
    AdminCartReminderView,
)

router = DefaultRouter()
router.register('orders', OrderViewSet, basename='orders')

urlpatterns = [
    path('', include(router.urls)),
    path('cart/', CartViewSet.as_view({'get': 'list'})),
    path('cart/add/', CartViewSet.as_view({'post': 'add'})),
    path('cart/update/', CartViewSet.as_view({'post': 'update_item'})),
    path('cart/merge/', CartViewSet.as_view({'post': 'merge'})),
    path('cart/coupon/apply/', CartViewSet.as_view({'post': 'apply_coupon'})),
    path('cart/coupon/remove/', CartViewSet.as_view({'post': 'remove_coupon'})),
    path('cart/clear/', CartViewSet.as_view({'post': 'clear_cart'})),
    path('cart/checkout/', CartViewSet.as_view({'post': 'checkout'})),
    path('cart/remove/<int:product_id>/', CartViewSet.as_view({'post': 'remove'})),
    path('track/', GuestOrderTrackView.as_view({'post': 'create'})),
    path('admin/analytics/', AdminAnalyticsView.as_view()),
    path('admin/reports/', AdminReportsView.as_view()),
    path('admin/carts/', AdminAbandonedCartsView.as_view(), name='admin-abandoned-carts'),
    path('admin/carts/remind/', AdminCartReminderView.as_view(), name='admin-cart-remind'),
    path('delivery-zones/', DeliveryZonesView.as_view(), name='delivery-zones'),
    path('admin/orders/export/', OrdersCSVExportView.as_view()),
    path('admin/invoices/', InvoiceListView.as_view(), name='admin-invoice-list'),
    path('admin/invoices/<int:invoice_id>/', InvoiceDetailView.as_view(), name='admin-invoice-detail'),
    path('admin/invoices/<int:invoice_id>/download/', InvoiceDownloadView.as_view(), name='admin-invoice-download'),
    path('admin/invoices/<int:invoice_id>/regenerate/', InvoiceRegenerateView.as_view(), name='admin-invoice-regenerate'),
    path('admin/invoices/<int:invoice_id>/resend/', InvoiceResendView.as_view(), name='admin-invoice-resend'),
]
