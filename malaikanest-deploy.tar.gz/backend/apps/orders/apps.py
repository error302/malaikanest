import logging

from django.apps import AppConfig

logger = logging.getLogger(__name__)


class OrdersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.orders'
    verbose_name = 'Orders'

    def ready(self):
        # import signals
        try:
            import apps.orders.signals  # noqa: F401
        except Exception:
            logger.debug("orders signals import skipped")
