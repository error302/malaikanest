from .base import *
import os
from pathlib import Path
from .guards import enforce_postgresql_only

DEBUG = True

ALLOWED_HOSTS = [
    h.strip()
    for h in os.getenv(
        "ALLOWED_HOSTS",
        "localhost,127.0.0.1,0.0.0.0,backend,frontend,host.docker.internal",
    ).split(",")
    if h.strip()
]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.getenv('DB_NAME', 'malaika_db'),
        'USER': os.getenv('DB_USER', 'postgres'),
        'PASSWORD': os.getenv('DB_PASSWORD', 'postgres'),
        'HOST': os.getenv('DB_HOST', 'localhost'),
        'PORT': os.getenv('DB_PORT', '5432'),
        "CONN_MAX_AGE": globals().get("DB_CONN_MAX_AGE", 600),
    }
}

enforce_postgresql_only(DATABASES, context="dev")

DATABASE_ROUTERS = configure_read_replica(DATABASES)

SIMPLE_JWT["AUTH_COOKIE_SECURE"] = False
SIMPLE_JWT["AUTH_COOKIE_SAMESITE"] = "Lax"

SECURE_SSL_REDIRECT = False
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False

# Always allow both localhost variants in development to avoid CORS issues
# when frontend is launched as http://localhost:3000 or http://127.0.0.1:3000.
_dev_origins = {'http://localhost:3000', 'http://127.0.0.1:3000'}
_existing_cors = set(globals().get('CORS_ALLOWED_ORIGINS', []))
CORS_ALLOWED_ORIGINS = sorted(_existing_cors | _dev_origins)

_existing_csrf = set(globals().get('CSRF_TRUSTED_ORIGINS', []))
CSRF_TRUSTED_ORIGINS = sorted(_existing_csrf | _dev_origins)

if not os.getenv('EMAIL_HOST'):
    EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
    DEFAULT_FROM_EMAIL = 'Malaika Nest <dev@malaikanest.local>'

CELERY_BROKER_URL = os.getenv('CELERY_BROKER_URL', 'redis://localhost:6379/0')
CELERY_RESULT_BACKEND = os.getenv('CELERY_RESULT_BACKEND', CELERY_BROKER_URL)
CELERY_TASK_ALWAYS_EAGER = os.getenv('CELERY_TASK_ALWAYS_EAGER', 'true').strip().lower() in {'1', 'true', 'yes', 'on'}
CELERY_TASK_EAGER_PROPAGATES = True

# Dev-only tooling (Phase 5): debug toolbar + N+1 query-count middleware.
if "django_extensions" in INSTALLED_APPS:
    INTERNAL_IPS = ["127.0.0.1", "localhost"]

if "debug_toolbar" not in INSTALLED_APPS:
    INSTALLED_APPS = list(INSTALLED_APPS) + ["debug_toolbar"]

if "debug_toolbar.middleware.DebugToolbarMiddleware" not in MIDDLEWARE:
    MIDDLEWARE = list(MIDDLEWARE) + ["debug_toolbar.middleware.DebugToolbarMiddleware"]

# Debug toolbar trips its E001 check during `manage.py test` (Django flips
# DEBUG to False under tests). Bypass per django-debug-toolbar's documented hint.
DEBUG_TOOLBAR_CONFIG = {
    "IS_RUNNING_TESTS": False,
}

if "apps.core.middleware.QueryCountMiddleware" not in MIDDLEWARE:
    MIDDLEWARE = list(MIDDLEWARE) + ["apps.core.middleware.QueryCountMiddleware"]
